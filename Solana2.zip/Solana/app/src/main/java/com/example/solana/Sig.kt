package com.example.solana

import android.R.id.checkbox
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class Sig : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }
    fun terminosycondiciones(view: View) {

        val intent = Intent(this, Terminos::class.java)
        startActivity(intent)
    }
    fun regresarInicio(view: View) {

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
    fun terminarRegistro(view: View) {

        //Proceso para comprobar que los campos de texto estan llenos
        var editText = findViewById<EditText>(R.id.sexo)
        val sexo = editText.text.toString()
        var editText1 = findViewById<EditText>(R.id.NombreApellido)
        val nombre =editText1.text.toString()
        var editText2 = findViewById<EditText>(R.id.email)
        val email =editText2.text.toString()
        var editText3 = findViewById<EditText>(R.id.edad)
        val edad =editText3.text.toString()
        var editText4 = findViewById<EditText>(R.id.telefono)
        val tel =editText4.text.toString()
        var editText5 = findViewById<EditText>(R.id.ocupacion)
        val ocupa =editText5.text.toString()
        var editText6 = findViewById<EditText>(R.id.sociodemo)
        val sociode =editText6.text.toString()
        var editText7 = findViewById<EditText>(R.id.tipodecancer)
        val cancer =editText7.text.toString()
        var editText8 = findViewById<EditText>(R.id.tratamiento)
        val tratamiento =editText8.text.toString()
        var editText9= findViewById<EditText>(R.id.contraseña)
        val contra =editText9.text.toString()
        var editText10= findViewById<EditText>(R.id.estado)
        val estado =editText10.text.toString()


        if (sexo.isEmpty() || nombre.isEmpty()||email.isEmpty()||edad.isEmpty()||tel.isEmpty()||ocupa.isEmpty()||sociode.isEmpty()||cancer.isEmpty()||tratamiento.isEmpty()||contra.isEmpty()||estado.isEmpty()) {
            val context = applicationContext
            val text: CharSequence = "Un campo de texto está vacío"
            val duration = Toast.LENGTH_SHORT
            val toast = Toast.makeText(context, text, duration)
            toast.show()
            return;
        }
        //Termina proceso de comprobacion

        var condiciones: CheckBox = findViewById(R.id.acepto_terminos_y_condiciones)
        if (!condiciones.isChecked) {
            val context = applicationContext
            val text: CharSequence = "Tienes que aceptar los términos y condiciones para continuar"
            val duration = Toast.LENGTH_SHORT
            val toast = Toast.makeText(context, text, duration)
            toast.show()
            return;
        }//If para verificar si se han aceptado los terminos y condiciones
        else {

            val context = applicationContext
            val text: CharSequence = "¡Ya te has registrado!"
            val duration = Toast.LENGTH_SHORT

            val toast = Toast.makeText(context, text, duration)
            toast.show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }//



}