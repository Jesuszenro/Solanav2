package com.example.solana

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Terminos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.terminosycondiciones)
    }
    fun regresarRegistro2(view: View) {

        val intent = Intent(this, Sig::class.java)
        startActivity(intent)
    }
    fun regresarRegistro1(view: View) {

        val intent = Intent(this, Sig::class.java)
        startActivity(intent)
    }//Botones regresar Registro 1 y 2 regresan a Login...
}